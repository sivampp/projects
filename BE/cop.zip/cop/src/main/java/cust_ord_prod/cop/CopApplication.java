package cust_ord_prod.cop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CopApplication {

	public static void main(String[] args) {
		SpringApplication.run(CopApplication.class, args);
	}

}
