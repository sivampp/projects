package cust_ord_prod.cop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CopApplicationTests {

	@Test
	void contextLoads() {
	}

}
